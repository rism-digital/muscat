#!/usr/bin/env ruby

File.open('texts.tsv', 'w') do |texts|
  File.open('text_error.tsv', 'w') do |errors|
    Dir['*.darms'].sort.each do |file|
      name  = File.basename(file, '.darms')
      darms = File.read(file).strip

      # Exactly one @ and one $, in the correct order.
      if darms.count('@') == 1 &&
         darms.count('$') == 1 &&
         darms.index('@') < darms.index('$')

        text = darms[/@([^$]*)\$/, 1]
        texts.puts "#{name}\t#{text}"
      else
        errors.puts "#{name}\t#{darms}"
      end
    end
  end
end
