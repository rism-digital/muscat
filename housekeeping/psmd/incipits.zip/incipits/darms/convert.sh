#!/usr/bin/env bash

set -u


for file in *.darms; do
  [ -e "$file" ] || continue

  base="${file%.darms}"

  echo "Converting $file"

  verovio -f darms -t pae "$file" -o "${base}.pae"
echo $?
#  verovio -f darms -t svg "$file" -o "${base}.svg"
done
