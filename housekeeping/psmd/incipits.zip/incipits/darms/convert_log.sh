#!/usr/bin/env bash

set -u


# Start fresh
: > errors.tsv

for file in *.darms; do
  [ -e "$file" ] || continue

  base="${file%.darms}"

  echo "Converting $file"

  while IFS= read -r line; do
    # Keep Verovio output visible
    echo "$line"

    case "$line" in
      *Warning*|*Error*)
        printf '%s\t%s\n' "$file" "$line" >> errors.tsv
        ;;
    esac
  done < <(
    verovio \
      -f darms \
      -t pae \
      "$file" \
      -o "${base}.pae" \
      2>&1
  )
done
